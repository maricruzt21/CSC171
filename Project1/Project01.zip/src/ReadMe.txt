/*
	 * Name: Maricruz Tolosa Amaya  ID: 29988518
	 * Lab: TR 11:05 - 12:20
	 * HW 06
	 * I did not collaborate with anyone on this assignment 
	 */



This project is titled under the file ‘Project1.java’. To play, just hit the run button and the prompts should be printed in the console. In this game, the user gets instructions that will clarify on what to do. The wall height and distance  is randomized every game. The range for the wall height can range from 0 meters to 500 meters. The range for the wall distance can be from 0 to 1000 meters. It asks for the player to input their guesses on the launch angle and launch speed that is required to make the projectile go over the wall. The user is allowed one guess per round. The score is then calculated at the end of every round and printed out. Once the player chooses to stop playing, the score of every round played is then printed out and shown to the player. In this game, I changed some of the scores from the project assignment. If it is close clear then the player gets a net score of +5, and if it is a far clear then they get +7. A near miss is -1 from the overall score and a far miss is -3 points. 


Enjoy!