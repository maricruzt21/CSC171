/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * ID#: 29988518
 * Project #1
 * Lab: MW 2:00-3:15
 * 
 * I did not collaborate with anyone on this assignment
 */

This is my submission for Project 1 - TTY. This is a simple projectile game. Rules are: Wall's height range - 0m to 500m. Wall's distance range - 0m to 100m. 
The wall will randomly generate each round. Also the wall is moving at a speed of 5 m/s towards the player. The longer it takes the user to input values, the closer the wall gets. The wall has the possibility of hitting the player. If it does, then the wall resets. After the player enters a launch speed and launch angle, the program will inform the player their score and how did they do. They will have the option to quit after every round. 

Scoring:
   - Every launch is: -1 
   - Player launched projectile over wall by over 3m : +5
   - Player launched projectile over wall by less than 3m: + 3
   - Player launched projectile that didn't make it over by 3m or less: -1    
   - Player launched projectile that didn't make it over by more than 3m: -2

Extra Credit: 
	I did two things to be considered for extra credit. The first thing I did was to randomly print out statements based on the outcome (projectile made it over the wall or not). I made two separate arrays and it prints out the result. As suggested, I incorporated a speed for the wall to move by. The wall gets closer as time goes by and the player hasn't entered inputs. The player can get hit by the wall. 



You just need to run program and enter values when prompted. The only file for this project is "Project_1.java". The code is commented. 
Thank you!