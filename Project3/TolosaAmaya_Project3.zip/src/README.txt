/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * Project #3
 * Lab: MW 2:00-3:15
 * 
 * I did not collaborate with anyone on this assignment
 */


Not much was done for this project. Run only the Firework.java file. It only contains a Frame and it displays 3 text fields and a calculate button. Enter values in the text fields and press 'Calculate'. Then it will print in the console the X, Y position. 