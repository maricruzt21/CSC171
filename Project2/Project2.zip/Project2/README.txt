/*
	 * Name: Maricruz Tolosa Amaya  ID: 29988518
	 * Lab: TR 11:05 - 12:20
	 * Project 02
	 * I did not collaborate with anyone on this assignment 
	 */


The file where the Project file is located is named ‘Project2.java’.
In this game, I created string arrays to store the values for each separate course, golf clubs, and power for the putt. Then to access each individual data value, such as getting the the mean for each golf club, I separated each value by the comma to just get an integer. The person could stay at the tee/hole for a long time. They could overhit to pass the hole. 

I am very unfamiliar with golf, so while creating this project I was often confused. For the scoring, i made it so that when they hit and make it into the hole less than the number of par for that specific hole, they would gets points subtracted from their score. If they hit it more times than the par, then their score would increase. 

