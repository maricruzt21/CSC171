/*
	 * Name: Maricruz Tolosa Amaya  ID: 29988518
	 * Lab: TR 11:05 - 12:20
	 * Project 04
	 * I did not collaborate with anyone on this assignment 
	 */



This is my submission for Project 4. I chose the second option of the video game voice, which was the drone. The code for the actual game is under “Game.java” meanwhile the setup/frame is under “GameFrame.java”. Either can be ruined to play the game. There are 2 levels in the game: Level 1 and Level 2. Both have randomized wall heights for the user to maneuver the drone in between. There is an red line which is the “finish line” of the level. To play, the right and left arrows key is used to rotate the position of the rocket/drone. The up arrow key is used to go further right. 