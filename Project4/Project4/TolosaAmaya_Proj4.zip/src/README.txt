/* Name: Maricruz Tolosa Amaya
 * Net ID: mtolosaa
 * Project #4
 * Lab: MW 2:00-3:15
 * 
 * I did not collaborate with anyone on this assignment
 */


This is my submission for Project 4 - Graphipult. The program is under one class file - "Projectile.java". You just need to run the program. 

When the program is ran, the frame should appear(there are times in which it can glitch and not appear but just run the program again). On the frame, there are 2 sliders, velocity and launch angle, along with labels and buttons. 

To start, press the "Start Game" button or proceed to change the slider value but make sure to press the "Start Game" button. For launch angle the range is: 0 to 90 degrees. For launch velocity the range is: 0 - 200 meter per second. The wall will already be placed once the "start game" button is pressed. The wall's position is random and depends on the screen size. The wall's height can be anywhere from half of the frame size to the bottom(initially, I set the frame size to be 1000,1000 so the wall height can as tall as 500m). The wall distance can be anywhere along the X axis(again, the frame is set at 1000,1000 so the wall can be ~1000 meters away). Once you have the velocity and angle, press the launch button. Once the button is pressed, the wall will move towards "you" (to the left). The projectile will be animated to where it lands. It will inform you, via label, of the results and score will be updated. If you made it over in a single try, then it draws the wall at another position and you can keep playing, but do it fast as the wall is still moving. You can end whenever you want. If you didn't make it over in the first try, then you have 2 tries left (3 tries in total). Score will keep decreasing. Press the "New Game" button anytime to restart/reset everything. Also, you cannot launch, once the launch  button has been pressed. You need to wait until the ball lands and you get your result to press launch again.

Extra Credit: 

I animated the wall to move towards the left, once the launch button is pressed. 

Not sure if these count for extra credit but: 
Just like project 1, I created random strings to appear on the label, depending if it was a success or not. Random color is generated each time. 



